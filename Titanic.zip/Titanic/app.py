import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore")
import streamlit as st 
from sklearn.ensemble import RandomForestClassifier

st.title("Titanic Survival Prediction")

@st.cache_data

def model():
    df = pd.read_csv("Titanic-Dataset.csv")
    df["Age"]=round(df["Age"])
    df["Age"].fillna(df["Age"].mean(),inplace=True)
    df.drop(columns = ["Cabin","Fare","Ticket","Name","PassengerId"],inplace = True)
    df["Embarked"].ffill(inplace = True)
    q1=df["Age"].quantile(0.25)
    q3=df["Age"].quantile(0.75)
    iqr=q3-q1
    uf=q3+(1.5*iqr)
    lf=q1-(1.5*iqr)
    df["Age"]=np.where(df["Age"]>uf,uf,df["Age"])
    df["Age"]=np.where(df["Age"]<lf,lf,df["Age"])
    df["Sex"] = np.where(df["Sex"] == "male",1,0)
    df["Age"] = round(df["Age"])
    df["fam"] = df["SibSp"]+df["Parch"]
    df.drop(columns = ["SibSp"],inplace = True)
    df.drop(columns = ["Parch"],inplace = True)
    df = pd.get_dummies(df,columns = ["Embarked"],drop_first = True)
    x = df.drop(columns=["Survived"])
    y = df["Survived"]
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=88)
    rf=RandomForestClassifier(n_estimators=100,criterion="entropy",min_samples_split=50,max_depth=10,random_state=88)
    rf.fit(x_train,y_train)
    return rf
rf = model()

st.sidebar.header("Enter Details")

Pclass = st.sidebar.selectbox("Pclass",[0,1,2,3])
Age = st.sidebar.slider("Age",2,60,15)
Sex = st.sidebar.selectbox("Sex",["Male","Female"])
fam = st.sidebar.slider("fam",0,10,3)
Embarked_Q = st.sidebar.selectbox("Embarked_Q",["True","False"])
Embarked_S = st.sidebar.selectbox("Embarked_S",["True","False"])

Sex = 1 if Sex == "Male" else 0
Embarked_Q = 1 if Embarked_Q == "True" else 0
Embarked_S = 1 if Embarked_S == "True" else 0


input_data = np.array([[Pclass,Age,Sex,fam,Embarked_Q,Embarked_S]])

if st.button("Predict Survival"):
    prediction = rf.predict(input_data) 

    if prediction[0] == 1:
        st.success("Survived")
    else:
        st.error("Not Survived")









